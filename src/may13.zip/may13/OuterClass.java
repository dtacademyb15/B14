package may13;

public class OuterClass {





    private class InnerClass{

    }

}


