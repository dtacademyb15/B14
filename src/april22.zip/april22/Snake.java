package april22;

public class Snake extends Animal{

    public void eat(){
        System.out.println("Snake eats mice");
    }

    public void move(){
        System.out.println("Snake crawls");
    }

    public void sleep(){
        System.out.println("Snake does not sleep at night");
    }
}
