package april22;

public class Bear extends Animal{


    public void eat(){
        System.out.println("Bear eats salmon");
    }

    public void move(){
        System.out.println("Bear stands on feet");
    }

    public void sleep(){
        System.out.println("Bear hibernates");
    }
}
