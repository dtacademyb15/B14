package april22;

public class Bird extends Animal{


    public void eat(){
        System.out.println("Bird eats worms");
    }

    public void move(){
        System.out.println("Bird flies");
    }

    public void sleep(){
        System.out.println("Bird sleeps on trees");
    }
}
