package april22.polymorphismExamples;

public class Fruit {


    public void eat(){
        System.out.println("Eating fruit");
    }
}
