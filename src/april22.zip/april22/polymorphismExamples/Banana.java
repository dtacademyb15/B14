package april22.polymorphismExamples;

public class Banana extends Fruit{

    public void eat(){
        System.out.println("Making banana bread");
    }
}
