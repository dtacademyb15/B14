package april22;

public class Animal {


    public void eat(){
        System.out.println("Animal eats");
    }

    public void move(){
        System.out.println("Animal moves");
    }

    public void sleep(){
        System.out.println("Animal sleeps");
    }

}
