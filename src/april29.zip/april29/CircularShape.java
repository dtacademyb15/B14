package april29;

public abstract class CircularShape extends Shape{ //subclass can also be abstarct
    // it simply means subclass inherits super's abstract methods


    public abstract void calculateCircumference();
}
