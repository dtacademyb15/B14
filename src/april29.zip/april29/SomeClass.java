package april29;

public abstract class SomeClass {

}
