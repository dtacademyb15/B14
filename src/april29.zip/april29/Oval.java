package april29;

public class Oval extends CircularShape{
    @Override
    public void calculateCircumference() {

    }

    @Override
    public double getArea() {
        return 0;
    }

    @Override
    public double getPerimeter() {
        return 0;
    }
}
