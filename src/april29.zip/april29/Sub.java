package april29;

public class Sub extends Super{
}
