package may1;

public abstract class Fruit implements Edible{


}
