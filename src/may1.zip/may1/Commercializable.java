package may1;

public interface Commercializable extends Marketable{

    // classes extend another class (abstract or concrete)
    // classes(abstarct or concrete) implement interfaces
    // inteface extends another interface

    public abstract void makeMoney();
}
