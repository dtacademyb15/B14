package may1;

public class Banana extends Fruit{
    @Override
    public void howToEat() {
        System.out.println("Make banana bread");
    }
}
