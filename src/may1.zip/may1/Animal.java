package may1;

public abstract class Animal {

    public abstract void makeSound();

    public abstract void move();
}
