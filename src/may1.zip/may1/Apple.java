package may1;

public class Apple extends Fruit{
    @Override
    public void howToEat() {
        System.out.println("Make Apple Cider");
    }
}
