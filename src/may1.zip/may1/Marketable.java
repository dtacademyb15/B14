package may1;

public interface Marketable {

// public abstract void market(); // public and abstract are assumed
      void market(); // public and abstract are assumed
    // all interface abstract methods by default are public and abstract
}
