package may1;

public interface Consumable {

    void howToEat();
}
