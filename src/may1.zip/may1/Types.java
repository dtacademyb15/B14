package may1;

public class Types {

    //Java has 2 types: primitives and reference types

    // Reference types:
    // Class
    // Annotation
    // Interface
    // Record
    // Enum
    // array

}
