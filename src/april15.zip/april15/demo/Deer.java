package april15.demo;

public class Deer extends Animal{ // inherits non-private variables and methods




     boolean hasHorns;

    public boolean isHasHorns() {
        return hasHorns;
    }

    public void setHasHorns(boolean hasHorns) {
        this.hasHorns = hasHorns;
    }
}

