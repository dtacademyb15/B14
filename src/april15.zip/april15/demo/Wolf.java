package april15.demo;

public class Wolf extends Animal{

    boolean livesInPacks;

    public boolean isLivesInPacks() {
        return livesInPacks;
    }

    public void setLivesInPacks(boolean livesInPacks) {
        this.livesInPacks = livesInPacks;
    }
}
