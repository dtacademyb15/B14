package april15.demo;

public class Bear extends Animal {





    String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


}
