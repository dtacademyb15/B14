package april15.demo;

public class ServiceDog extends Dog{

    String assignedPerson;

    public String getAssignedPerson() {
        return assignedPerson;
    }

    public void setAssignedPerson(String assignedPerson) {
        this.assignedPerson = assignedPerson;
    }
}
