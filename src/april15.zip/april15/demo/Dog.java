package april15.demo;

public class Dog extends Animal{

    double olfactorySense;

    public double getOlfactorySense() {
        return olfactorySense;
    }

    public void setOlfactorySense(double olfactorySense) {
        this.olfactorySense = olfactorySense;
    }
}
