package april15.example;

import april15.protectedDemo.Employee;

public class Dev extends Employee {

    public void printExperience(){
        System.out.println(experience);
    }
}
