package april15.example;

public class LoginTests extends BaseTest{

    public void loginTest(){
        System.out.println("login Test");
    }
}
