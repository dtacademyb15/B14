package april15.example;

public class SignUpTests extends BaseTest{




    public void signUpTest(){
        System.out.println("Sign Up Test");
    }
}
