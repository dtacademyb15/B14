package april15.example;

import april15.protectedDemo.Employee;

public class Test {

    public static void main(String[] args) {

//        System.out.println(new Employee().title);
    }
}
