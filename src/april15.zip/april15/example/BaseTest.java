package april15.example;

public class BaseTest {

    static String pageName = "Test no ";
    static int num = 1;

    {
        System.out.println(pageName +  num + " tests started");
        num++;
    }
}
