package april15.example;

public class HomePageTests extends BaseTest{


    public void performUrlValidation(){
        System.out.println("Url validated");
    }



}
