package april15.constructorChaining;

public class Super {

    public Super(){
        //super();
        System.out.println("Super's constructor");
    }
}
