package april15.protectedDemo;

public class Test {


    public static void main(String[] args) {

        System.out.println(new Employee().title);
    }
}
