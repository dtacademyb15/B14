package april26;

public class Cat extends Animal{
}
