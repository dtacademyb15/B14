package april26;

public class Dog extends Animal{


    public void makeNoise(){
        System.out.println("Woof");
    }


    public void scratchWithFeet(){
        System.out.println("Dog is scratching its ears");
    }
}
