package april26;

public class Animal {


    public void makeNoise(){
        System.out.println("Generic animal sound");
    }
}
